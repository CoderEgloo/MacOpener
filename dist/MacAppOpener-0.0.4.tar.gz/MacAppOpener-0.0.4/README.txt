Project Description
 A simple python module that offers a MacOS alternative to the AppOpener module using the os module and difflib providing an easy way to open and close applications on MacOS using python. The module will search within the applications for the closeset module giving programmers a little leeway. 
 
Examples:

open("brave") #opens Brave Browser

close("discord") #closes Discord application
	 